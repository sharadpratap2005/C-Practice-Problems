/* Write a program to print the triangle using printf() statements. The program lets the user to input number of lines.
 */

#include <stdio.h>

int main()
{
    printf("%60s", "/\n");
    printf("%59s", "/\n");
    printf("%58s", "/\n");
    printf("%57s", "/\n");
    printf("%56s", "/\n");
    printf("%55s", "/\n");
    printf("%54s", "/\n");
    printf("%53s", "/\n");
    printf("%52s", "/\n");
    printf("%51s", "/\n");
    printf("%50s", "/\n");
    printf("%49s", "/\n");
    printf("%48s", "/\n");
    printf("%46s", "/");
    printf("%s", "_ _ _ _ _ _ _ _ _ _ _ _ _ _");

    printf("\n\n\n");
}
